# HybridFG

Modul LSPosed untuk frame generation (interpolasi 2x) dengan pilihan engine estimasi gerakan: **GPU** atau **CPU**.
Hanya untuk game OpenGL ES 3.x (hook `eglSwapBuffers`), arm64.

## Build
Push folder ini ke GitHub. Workflow `.github/workflows/build.yml` menghasilkan artifact `HybridFG-apk`
(`app-release.apk`, ditandatangani debug key). Butuh akses internet saat build (Gradle + ShadowHook dari Maven Central).

## Pakai
1. Pasang APK, aktifkan modul di LSPosed, centang game pada scope.
2. Buka app HybridFG: pilih engine, pilih game, Simpan. Restart game.
3. Pantau: `logcat -s HybridFG`.

## Cara kerja
- `HookEntry` (Java) hanya memuat `libhybridfg.so` ke proses game. Native lalu meng-hook `eglSwapBuffers` (ShadowHook).
- Tiap swap: salin back buffer -> tekstur, buat luma low-res, estimasi flow (three-step search, blok 4x4, jendela SAD 8x8),
  gambar frame tengah (t=0.5) dengan warp + fallback blend, swap frame tengah, lalu biarkan game swap frame aslinya.
- **GPU**: flow dihitung shader, tanpa lag tambahan.
- **CPU**: luma kecil dibaca balik async (PBO + fence, tidak pernah menunggu GPU), flow dihitung thread `hfg-flow`
  (NEON, di-pin ke core sesuai bitmask), hasilnya diunggah sebagai tekstur kecil. Warp tetap di GPU.
  Konsekuensi: frame tampil `lag` frame lebih lambat (default 2) supaya flow sempat selesai.

## Opsi
| Opsi | Arti |
|---|---|
| Skala flow | 2/4/8: pembagi resolusi luma. 2 = detail tinggi, mahal di GPU, masuk akal di CPU |
| Jangkauan | langkah awal pencarian: 2/4/8 = gerakan maksimum ±3/±7/±15 piksel flow |
| Lag | hanya mode CPU. 2 atau 3 frame |
| Core | bitmask hex, `C0` = cpu6+cpu7 |

## Batasan
- Vulkan belum didukung (tidak ada hook `vkQueuePresentKHR`).
- Mulus hanya jika refresh rate layar >= 2x fps game (mis. game dikunci 60 di layar 120 Hz).
- Gerakan cepat di luar jangkauan pencarian jatuh ke blend biasa; HUD/teks ikut ter-warp.
- Konfigurasi dibaca saat game start (XSharedPreferences), jadi restart game setelah Simpan.
