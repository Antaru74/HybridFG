package de.robv.android.xposed;
import java.util.Set;
public class XSharedPreferences {
    public XSharedPreferences(String packageName, String prefFileName) { throw new RuntimeException("stub"); }
    public boolean getBoolean(String key, boolean defValue) { throw new RuntimeException("stub"); }
    public int getInt(String key, int defValue) { throw new RuntimeException("stub"); }
    public String getString(String key, String defValue) { throw new RuntimeException("stub"); }
    public Set<String> getStringSet(String key, Set<String> defValues) { throw new RuntimeException("stub"); }
}
