#pragma once
#include <condition_variable>
#include <cstdint>
#include <deque>
#include <mutex>
#include <thread>
#include <vector>

namespace hfg {

// Penalti SAD per piksel |dx|+|dy|. Harus sama dengan uniform uBias di shader flow GPU.
constexpr int kBias = 6;

// Estimasi gerakan di CPU: three-step search, blok 4x4 dengan jendela SAD 8x8 pada luma low-res.
// Format keluaran sama persis dengan shader GPU: 2 byte per blok (dx+128, dy+128).
class CpuFlow {
public:
    CpuFlow(int lw, int lh, int step, unsigned cpuMask);
    ~CpuFlow();

    // luma: lw*lh byte (baris 0 = baris tekstur 0). Harus dipanggil berurutan per frame id.
    void submit(uint64_t id, const uint8_t* luma);
    // Ambil flow(id-1 -> id). Hasil dengan id lebih kecil dibuang. false bila belum siap.
    bool take(uint64_t id, std::vector<uint8_t>& out);

private:
    struct Job { uint64_t id; std::vector<uint8_t> luma; };
    struct Res { uint64_t id; std::vector<uint8_t> data; };

    void run();
    std::vector<uint8_t> pad(const std::vector<uint8_t>& raw) const;
    void compute(const uint8_t* prev, const uint8_t* cur, std::vector<uint8_t>& out) const;

    int lw_, lh_, step_;
    unsigned mask_;
    std::mutex mu_;
    std::condition_variable cv_;
    std::deque<Job> jobs_;
    std::deque<Res> res_;
    bool stop_ = false;
    std::thread th_;
};

}  // namespace hfg
