#include <EGL/egl.h>
#include <android/log.h>
#include <jni.h>

#include "fg.h"
#include "shadowhook.h"

#define TAG "HybridFG"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)

namespace {

EGLBoolean (*orig_swap)(EGLDisplay, EGLSurface) = nullptr;
EGLBoolean (*orig_damage)(EGLDisplay, EGLSurface, const EGLint*, EGLint) = nullptr;
thread_local bool tl_busy = false;  // eglSwapBuffers asli bisa memanggil varian damage di dalam libEGL

EGLBoolean hk_swap(EGLDisplay d, EGLSurface s) {
    if (tl_busy) return orig_swap(d, s);
    tl_busy = true;
    hfg::before_swap(d, s, orig_swap);
    EGLBoolean r = orig_swap(d, s);
    tl_busy = false;
    return r;
}

EGLBoolean hk_damage(EGLDisplay d, EGLSurface s, const EGLint* rects, EGLint n) {
    if (tl_busy || !orig_swap) return orig_damage(d, s, rects, n);
    tl_busy = true;
    hfg::before_swap(d, s, orig_swap);
    EGLBoolean r = orig_damage(d, s, rects, n);
    tl_busy = false;
    return r;
}

}  // namespace

extern "C" JNIEXPORT void JNICALL
Java_com_hybridfg_Native_init(JNIEnv*, jclass, jint engine, jint flowDiv, jint step, jint lag, jint cpuMask) {
    static bool done = false;
    if (done) return;
    done = true;

    hfg::Config c;
    c.engine = engine;
    c.flowDiv = flowDiv;
    c.step = step;
    c.lag = lag;
    c.cpuMask = (unsigned)cpuMask;
    hfg::set_config(c);

    shadowhook_init(SHADOWHOOK_MODE_UNIQUE, false);
    void* s1 = shadowhook_hook_sym_name("libEGL.so", "eglSwapBuffers", (void*)hk_swap, (void**)&orig_swap);
    void* s2 = shadowhook_hook_sym_name("libEGL.so", "eglSwapBuffersWithDamageKHR", (void*)hk_damage,
                                        (void**)&orig_damage);
    LOGI("hook eglSwapBuffers=%s eglSwapBuffersWithDamageKHR=%s engine=%s", s1 ? "ok" : "GAGAL",
         s2 ? "ok" : "tidak ada", engine == 1 ? "CPU" : "GPU");
}
