#pragma once
#include <EGL/egl.h>

namespace hfg {

struct Config {
    int engine = 0;        // 0 = flow di GPU, 1 = flow di CPU
    int flowDiv = 4;       // pembagi resolusi untuk luma low-res: 2 / 4 / 8
    int step = 4;          // langkah awal three-step search: 2 / 4 / 8 (jangkauan +-(2*step-1) piksel low-res)
    int lag = 2;           // lag frame untuk mode CPU: 2 / 3
    unsigned cpuMask = 0xC0;  // affinity thread flow (bit n = cpu n)
};

typedef EGLBoolean (*SwapFn)(EGLDisplay, EGLSurface);

void set_config(const Config& c);

// Dipanggil tepat sebelum eglSwapBuffers asli milik game. Boleh menampilkan frame tambahan lewat
// `plain` (eglSwapBuffers asli), lalu meninggalkan frame yang harus tampil berikutnya di back buffer.
void before_swap(EGLDisplay dpy, EGLSurface surf, SwapFn plain);

}  // namespace hfg
