#include "fg.h"
#include "cpuflow.h"

#include <GLES3/gl3.h>
#include <android/log.h>
#include <string.h>
#include <time.h>

#include <deque>
#include <memory>
#include <vector>

#define TAG "HybridFG"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

namespace hfg {
namespace {

Config g_cfg;

uint64_t now_ns() {
    timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return (uint64_t)t.tv_sec * 1000000000ull + (uint64_t)t.tv_nsec;
}

// ------------------------------------------------------------------ shader

const char* kVS = R"GLSL(#version 300 es
out vec2 vUv;
void main() {
  vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));
  vUv = p;
  gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);
})GLSL";

// Salin tekstur ke back buffer.
const char* kFSBlit = R"GLSL(#version 300 es
precision highp float;
uniform sampler2D uTex;
in vec2 vUv;
out vec4 o;
void main() { o = vec4(texture(uTex, vUv).rgb, 1.0); }
)GLSL";

// Luma low-res, 4 piksel horizontal dipak ke satu texel RGBA8 (lebar = lw/4).
// Dibaca balik oleh CPU sebagai array byte lw*lh yang rapat.
const char* kFSLuma = R"GLSL(#version 300 es
precision highp float;
precision highp int;
uniform sampler2D uSrc;
uniform ivec2 uLow;
out vec4 o;
void main() {
  ivec2 f = ivec2(gl_FragCoord.xy);
  vec2 low = vec2(uLow);
  vec2 e = 0.25 / low;
  vec4 r = vec4(0.0);
  for (int c = 0; c < 4; c++) {
    vec2 uv = (vec2(float(f.x * 4 + c), float(f.y)) + 0.5) / low;
    vec3 s = texture(uSrc, uv + vec2(-e.x, -e.y)).rgb
           + texture(uSrc, uv + vec2( e.x, -e.y)).rgb
           + texture(uSrc, uv + vec2(-e.x,  e.y)).rgb
           + texture(uSrc, uv + vec2( e.x,  e.y)).rgb;
    r[c] = dot(s * 0.25, vec3(0.299, 0.587, 0.114));
  }
  o = r;
}
)GLSL";

// Flow GPU: three-step search, blok 4x4 + jendela SAD 8x8. Setara dengan CpuFlow::compute.
// Keluaran RG8: (dx+128, dy+128)/255 dengan cur(x) ~ prev(x + d).
const char* kFSFlow = R"GLSL(#version 300 es
precision highp float;
precision highp int;
precision highp sampler2D;
uniform sampler2D uPrev;
uniform sampler2D uCur;
uniform ivec2 uLow;
uniform int uStep;
uniform float uBias;
out vec4 o;

float L(sampler2D t, ivec2 p) {
  p = clamp(p, ivec2(0), uLow - ivec2(1));
  vec4 v = texelFetch(t, ivec2(p.x >> 2, p.y), 0);
  return v[p.x & 3];
}

float c[64];
ivec2 org;

float sad(ivec2 d) {
  float s = 0.0;
  for (int j = 0; j < 8; j++)
    for (int i = 0; i < 8; i++)
      s += abs(c[j * 8 + i] - L(uPrev, org + ivec2(i, j) + d));
  return s * 255.0;
}

void main() {
  ivec2 b = ivec2(gl_FragCoord.xy);
  org = ivec2(b.x * 4 - 2, b.y * 4 - 2);
  for (int j = 0; j < 8; j++)
    for (int i = 0; i < 8; i++)
      c[j * 8 + i] = L(uCur, org + ivec2(i, j));
  ivec2 best = ivec2(0);
  float bestC = sad(best);
  for (int s = uStep; s >= 1; s >>= 1) {
    ivec2 ctr = best;
    for (int j = -1; j <= 1; j++) {
      for (int i = -1; i <= 1; i++) {
        if (i == 0 && j == 0) continue;
        ivec2 d = ctr + ivec2(i, j) * s;
        float cost = sad(d) + uBias * float(abs(d.x) + abs(d.y));
        if (cost < bestC) { bestC = cost; best = d; }
      }
    }
  }
  o = vec4((vec2(best) + 128.0) / 255.0, 0.0, 1.0);
}
)GLSL";

// Frame tengah t=0.5: x_prev = x + d/2, x_cur = x - d/2. Bila keduanya tidak cocok (oklusi),
// jatuh kembali ke blend biasa supaya tidak muncul ghosting parah.
const char* kFSWarp = R"GLSL(#version 300 es
precision highp float;
uniform sampler2D uA;
uniform sampler2D uB;
uniform sampler2D uFlow;
uniform vec2 uInvLow;
in vec2 vUv;
out vec4 o;
void main() {
  vec2 d = (texture(uFlow, vUv).rg * 255.0 - 128.0) * uInvLow;
  vec3 a = texture(uA, vUv + 0.5 * d).rgb;
  vec3 b = texture(uB, vUv - 0.5 * d).rgb;
  vec3 a0 = texture(uA, vUv).rgb;
  vec3 b0 = texture(uB, vUv).rgb;
  float m = smoothstep(0.12, 0.35, length(a - b));
  o = vec4(mix(0.5 * (a + b), 0.5 * (a0 + b0), m), 1.0);
}
)GLSL";

GLuint compile(GLenum type, const char* src) {
    GLuint s = glCreateShader(type);
    glShaderSource(s, 1, &src, nullptr);
    glCompileShader(s);
    GLint ok = 0;
    glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        char log[1024];
        glGetShaderInfoLog(s, sizeof(log), nullptr, log);
        LOGE("shader gagal: %s", log);
        glDeleteShader(s);
        return 0;
    }
    return s;
}

GLuint make_program(const char* fs) {
    GLuint v = compile(GL_VERTEX_SHADER, kVS);
    GLuint f = compile(GL_FRAGMENT_SHADER, fs);
    if (!v || !f) return 0;
    GLuint p = glCreateProgram();
    glAttachShader(p, v);
    glAttachShader(p, f);
    glLinkProgram(p);
    glDeleteShader(v);
    glDeleteShader(f);
    GLint ok = 0;
    glGetProgramiv(p, GL_LINK_STATUS, &ok);
    if (!ok) {
        char log[1024];
        glGetProgramInfoLog(p, sizeof(log), nullptr, log);
        LOGE("link gagal: %s", log);
        glDeleteProgram(p);
        return 0;
    }
    return p;
}

GLuint make_tex(int w, int h, GLenum fmt, GLint filter) {
    GLuint t = 0;
    glGenTextures(1, &t);
    glBindTexture(GL_TEXTURE_2D, t);
    glTexStorage2D(GL_TEXTURE_2D, 1, fmt, w, h);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, filter);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, filter);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    return t;
}

// ------------------------------------------------------------------ state

struct Pending { uint64_t id; int pbo; GLsync fence; };

struct Inst {
    EGLContext ctx = EGL_NO_CONTEXT;
    EGLSurface surf = EGL_NO_SURFACE;
    int w = 0, h = 0, lw = 0, lh = 0, fw = 0, fh = 0, K = 0;
    bool ok = false, failed = false;
    uint64_t n = 0, lastNs = 0;
    GLuint vao = 0, fbo = 0, pBlit = 0, pLuma = 0, pFlow = 0, pWarp = 0, flowTex = 0;
    GLint uBlitTex = -1, uLumaSrc = -1, uLumaLow = -1, uFlowPrev = -1, uFlowCur = -1, uFlowLow = -1,
          uFlowStep = -1, uFlowBias = -1, uWarpA = -1, uWarpB = -1, uWarpFlow = -1, uWarpInv = -1;
    std::vector<GLuint> ring, lum, pbo;
    std::vector<char> pboBusy;
    std::deque<Pending> pending;
    std::unique_ptr<CpuFlow> cpu;
    std::vector<uint8_t> flowBuf;
    uint64_t sFrames = 0, sMid = 0;
    double sMs = 0;
};

Inst g;

const GLenum kCaps[8] = {GL_SCISSOR_TEST, GL_BLEND, GL_DEPTH_TEST, GL_CULL_FACE, GL_STENCIL_TEST,
                         GL_DITHER, GL_RASTERIZER_DISCARD, GL_SAMPLE_ALPHA_TO_COVERAGE};
const GLenum kPS[10] = {GL_PACK_ALIGNMENT, GL_PACK_ROW_LENGTH, GL_PACK_SKIP_PIXELS, GL_PACK_SKIP_ROWS,
                        GL_UNPACK_ALIGNMENT, GL_UNPACK_ROW_LENGTH, GL_UNPACK_SKIP_PIXELS,
                        GL_UNPACK_SKIP_ROWS, GL_UNPACK_IMAGE_HEIGHT, GL_UNPACK_SKIP_IMAGES};

// State GL milik game yang harus utuh setelah kita selesai (engine seperti Unity meng-cache state).
struct Saved {
    GLint prog, drawFbo, readFbo, vao, active, packBuf, unpackBuf;
    GLint vp[4], cm[4], tex[4], samp[4];
    GLboolean cap[8];
    GLint ps[10];
};

void save_state(Saved& s) {
    glGetIntegerv(GL_CURRENT_PROGRAM, &s.prog);
    glGetIntegerv(GL_DRAW_FRAMEBUFFER_BINDING, &s.drawFbo);
    glGetIntegerv(GL_READ_FRAMEBUFFER_BINDING, &s.readFbo);
    glGetIntegerv(GL_VERTEX_ARRAY_BINDING, &s.vao);
    glGetIntegerv(GL_ACTIVE_TEXTURE, &s.active);
    glGetIntegerv(GL_PIXEL_PACK_BUFFER_BINDING, &s.packBuf);
    glGetIntegerv(GL_PIXEL_UNPACK_BUFFER_BINDING, &s.unpackBuf);
    glGetIntegerv(GL_VIEWPORT, s.vp);
    glGetIntegerv(GL_COLOR_WRITEMASK, s.cm);
    for (int u = 0; u < 4; ++u) {
        glActiveTexture(GL_TEXTURE0 + u);
        glGetIntegerv(GL_TEXTURE_BINDING_2D, &s.tex[u]);
        glGetIntegerv(GL_SAMPLER_BINDING, &s.samp[u]);
    }
    for (int i = 0; i < 8; ++i) s.cap[i] = glIsEnabled(kCaps[i]);
    for (int i = 0; i < 10; ++i) glGetIntegerv(kPS[i], &s.ps[i]);
}

void restore_state(const Saved& s) {
    glUseProgram((GLuint)s.prog);
    glBindFramebuffer(GL_DRAW_FRAMEBUFFER, (GLuint)s.drawFbo);
    glBindFramebuffer(GL_READ_FRAMEBUFFER, (GLuint)s.readFbo);
    glBindVertexArray((GLuint)s.vao);
    for (int u = 0; u < 4; ++u) {
        glActiveTexture(GL_TEXTURE0 + u);
        glBindTexture(GL_TEXTURE_2D, (GLuint)s.tex[u]);
        glBindSampler(u, (GLuint)s.samp[u]);
    }
    glActiveTexture((GLenum)s.active);
    glBindBuffer(GL_PIXEL_PACK_BUFFER, (GLuint)s.packBuf);
    glBindBuffer(GL_PIXEL_UNPACK_BUFFER, (GLuint)s.unpackBuf);
    glViewport(s.vp[0], s.vp[1], s.vp[2], s.vp[3]);
    glColorMask(s.cm[0] != 0, s.cm[1] != 0, s.cm[2] != 0, s.cm[3] != 0);
    for (int i = 0; i < 8; ++i) {
        if (s.cap[i]) glEnable(kCaps[i]); else glDisable(kCaps[i]);
    }
    for (int i = 0; i < 10; ++i) glPixelStorei(kPS[i], s.ps[i]);
}

// Siapkan state netral untuk gambar 2D kita.
void begin_work() {
    for (int i = 0; i < 8; ++i) glDisable(kCaps[i]);
    glColorMask(GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);
    for (int i = 0; i < 10; ++i)
        glPixelStorei(kPS[i], (kPS[i] == GL_PACK_ALIGNMENT || kPS[i] == GL_UNPACK_ALIGNMENT) ? 1 : 0);
    glBindBuffer(GL_PIXEL_PACK_BUFFER, 0);
    glBindBuffer(GL_PIXEL_UNPACK_BUFFER, 0);
    for (int u = 0; u < 4; ++u) {
        glActiveTexture(GL_TEXTURE0 + u);
        glBindSampler(u, 0);
    }
    glActiveTexture(GL_TEXTURE0);
    glBindVertexArray(g.vao);
}

// ------------------------------------------------------------------ resource

void destroy(Inst& s, bool glValid) {
    s.cpu.reset();
    if (glValid) {
        for (GLuint t : s.ring) glDeleteTextures(1, &t);
        for (GLuint t : s.lum) glDeleteTextures(1, &t);
        for (GLuint b : s.pbo) glDeleteBuffers(1, &b);
        for (auto& p : s.pending) glDeleteSync(p.fence);
        if (s.flowTex) glDeleteTextures(1, &s.flowTex);
        if (s.fbo) glDeleteFramebuffers(1, &s.fbo);
        if (s.vao) glDeleteVertexArrays(1, &s.vao);
        if (s.pBlit) glDeleteProgram(s.pBlit);
        if (s.pLuma) glDeleteProgram(s.pLuma);
        if (s.pFlow) glDeleteProgram(s.pFlow);
        if (s.pWarp) glDeleteProgram(s.pWarp);
    }
    s = Inst();
}

bool fbo_complete(GLuint fbo, GLuint tex) {
    glBindFramebuffer(GL_FRAMEBUFFER, fbo);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, tex, 0);
    return glCheckFramebufferStatus(GL_FRAMEBUFFER) == GL_FRAMEBUFFER_COMPLETE;
}

bool init_resources(Inst& s) {
    glActiveTexture(GL_TEXTURE0);
    const bool cpuMode = g_cfg.engine == 1;
    const int lag = cpuMode ? g_cfg.lag : 0;
    s.lw = (s.w / g_cfg.flowDiv) & ~3;
    s.lh = (s.h / g_cfg.flowDiv) & ~3;
    if (s.lw < 64 || s.lh < 64) return false;
    s.fw = s.lw / 4;
    s.fh = s.lh / 4;
    s.K = lag + 3;

    glGenVertexArrays(1, &s.vao);
    glGenFramebuffers(1, &s.fbo);
    s.pBlit = make_program(kFSBlit);
    s.pLuma = make_program(kFSLuma);
    s.pFlow = make_program(kFSFlow);
    s.pWarp = make_program(kFSWarp);
    if (!s.pBlit || !s.pLuma || !s.pFlow || !s.pWarp) return false;

    s.uBlitTex = glGetUniformLocation(s.pBlit, "uTex");
    s.uLumaSrc = glGetUniformLocation(s.pLuma, "uSrc");
    s.uLumaLow = glGetUniformLocation(s.pLuma, "uLow");
    s.uFlowPrev = glGetUniformLocation(s.pFlow, "uPrev");
    s.uFlowCur = glGetUniformLocation(s.pFlow, "uCur");
    s.uFlowLow = glGetUniformLocation(s.pFlow, "uLow");
    s.uFlowStep = glGetUniformLocation(s.pFlow, "uStep");
    s.uFlowBias = glGetUniformLocation(s.pFlow, "uBias");
    s.uWarpA = glGetUniformLocation(s.pWarp, "uA");
    s.uWarpB = glGetUniformLocation(s.pWarp, "uB");
    s.uWarpFlow = glGetUniformLocation(s.pWarp, "uFlow");
    s.uWarpInv = glGetUniformLocation(s.pWarp, "uInvLow");

    for (int i = 0; i < s.K; ++i) {
        s.ring.push_back(make_tex(s.w, s.h, GL_RGBA8, GL_LINEAR));
        s.lum.push_back(make_tex(s.fw, s.lh, GL_RGBA8, GL_NEAREST));
    }
    s.flowTex = make_tex(s.fw, s.fh, GL_RG8, GL_LINEAR);

    if (!fbo_complete(s.fbo, s.ring[0]) || !fbo_complete(s.fbo, s.lum[0]) ||
        !fbo_complete(s.fbo, s.flowTex)) {
        LOGE("FBO tidak lengkap");
        return false;
    }

    if (cpuMode) {
        for (int i = 0; i < s.K; ++i) {
            GLuint b = 0;
            glGenBuffers(1, &b);
            glBindBuffer(GL_PIXEL_PACK_BUFFER, b);
            glBufferData(GL_PIXEL_PACK_BUFFER, (GLsizeiptr)s.lw * s.lh, nullptr, GL_STREAM_READ);
            s.pbo.push_back(b);
            s.pboBusy.push_back(0);
        }
        glBindBuffer(GL_PIXEL_PACK_BUFFER, 0);
        s.cpu.reset(new CpuFlow(s.lw, s.lh, g_cfg.step, g_cfg.cpuMask));
    }
    LOGI("init %dx%d low=%dx%d flow=%dx%d engine=%s lag=%d step=%d", s.w, s.h, s.lw, s.lh, s.fw, s.fh,
         cpuMode ? "CPU" : "GPU", lag, g_cfg.step);
    return true;
}

// ------------------------------------------------------------------ langkah pipeline

void bind_tex(int unit, GLuint tex) {
    glActiveTexture(GL_TEXTURE0 + unit);
    glBindTexture(GL_TEXTURE_2D, tex);
}

void capture(Inst& s, int k) {
    glBindFramebuffer(GL_READ_FRAMEBUFFER, 0);
    glBindFramebuffer(GL_DRAW_FRAMEBUFFER, s.fbo);
    glFramebufferTexture2D(GL_DRAW_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, s.ring[k], 0);
    glBlitFramebuffer(0, 0, s.w, s.h, 0, 0, s.w, s.h, GL_COLOR_BUFFER_BIT, GL_NEAREST);
}

void run_luma(Inst& s, int k) {
    glBindFramebuffer(GL_FRAMEBUFFER, s.fbo);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, s.lum[k], 0);
    glViewport(0, 0, s.fw, s.lh);
    glUseProgram(s.pLuma);
    bind_tex(0, s.ring[k]);
    glUniform1i(s.uLumaSrc, 0);
    glUniform2i(s.uLumaLow, s.lw, s.lh);
    glDrawArrays(GL_TRIANGLES, 0, 3);
}

void run_flow(Inst& s, int kprev, int kcur) {
    glBindFramebuffer(GL_FRAMEBUFFER, s.fbo);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, s.flowTex, 0);
    glViewport(0, 0, s.fw, s.fh);
    glUseProgram(s.pFlow);
    bind_tex(0, s.lum[kprev]);
    bind_tex(1, s.lum[kcur]);
    glUniform1i(s.uFlowPrev, 0);
    glUniform1i(s.uFlowCur, 1);
    glUniform2i(s.uFlowLow, s.lw, s.lh);
    glUniform1i(s.uFlowStep, g_cfg.step);
    glUniform1f(s.uFlowBias, (float)kBias);
    glDrawArrays(GL_TRIANGLES, 0, 3);
}

void issue_readback(Inst& s, uint64_t id) {
    int pi = -1;
    for (size_t i = 0; i < s.pbo.size(); ++i)
        if (!s.pboBusy[i]) { pi = (int)i; break; }
    if (pi < 0) return;  // semua PBO masih menunggu GPU: lewati frame ini (pasangan flow terputus)
    glBindFramebuffer(GL_READ_FRAMEBUFFER, s.fbo);  // lum[k] masih terpasang dari run_luma
    glReadBuffer(GL_COLOR_ATTACHMENT0);
    glBindBuffer(GL_PIXEL_PACK_BUFFER, s.pbo[pi]);
    glReadPixels(0, 0, s.fw, s.lh, GL_RGBA, GL_UNSIGNED_BYTE, nullptr);
    glBindBuffer(GL_PIXEL_PACK_BUFFER, 0);
    GLsync f = glFenceSync(GL_SYNC_GPU_COMMANDS_COMPLETE, 0);
    s.pboBusy[pi] = 1;
    s.pending.push_back({id, pi, f});
}

// Ambil luma yang sudah selesai dibaca GPU, tanpa pernah menunggu (menunggu = menghentikan pipeline GPU).
void poll_readbacks(Inst& s) {
    while (!s.pending.empty()) {
        Pending& p = s.pending.front();
        GLenum r = glClientWaitSync(p.fence, 0, 0);
        if (r == GL_TIMEOUT_EXPIRED) break;
        if (r != GL_WAIT_FAILED) {
            glBindBuffer(GL_PIXEL_PACK_BUFFER, s.pbo[p.pbo]);
            const void* m = glMapBufferRange(GL_PIXEL_PACK_BUFFER, 0, (GLsizeiptr)s.lw * s.lh, GL_MAP_READ_BIT);
            if (m) {
                s.cpu->submit(p.id, (const uint8_t*)m);
                glUnmapBuffer(GL_PIXEL_PACK_BUFFER);
            }
            glBindBuffer(GL_PIXEL_PACK_BUFFER, 0);
        }
        glDeleteSync(p.fence);
        s.pboBusy[p.pbo] = 0;
        s.pending.pop_front();
    }
}

bool fetch_flow(Inst& s, uint64_t head) {
    if (!s.cpu->take(head, s.flowBuf)) return false;
    bind_tex(0, s.flowTex);
    glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, s.fw, s.fh, GL_RG, GL_UNSIGNED_BYTE, s.flowBuf.data());
    return true;
}

void draw_warp(Inst& s, int kprev, int khead) {
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    glViewport(0, 0, s.w, s.h);
    glUseProgram(s.pWarp);
    bind_tex(0, s.ring[kprev]);
    bind_tex(1, s.ring[khead]);
    bind_tex(2, s.flowTex);
    glUniform1i(s.uWarpA, 0);
    glUniform1i(s.uWarpB, 1);
    glUniform1i(s.uWarpFlow, 2);
    glUniform2f(s.uWarpInv, 1.0f / (float)s.lw, 1.0f / (float)s.lh);
    glDrawArrays(GL_TRIANGLES, 0, 3);
}

void draw_blit(Inst& s, int k) {
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    glViewport(0, 0, s.w, s.h);
    glUseProgram(s.pBlit);
    bind_tex(0, s.ring[k]);
    glUniform1i(s.uBlitTex, 0);
    glDrawArrays(GL_TRIANGLES, 0, 3);
}

}  // namespace

void set_config(const Config& c) {
    g_cfg = c;
    if (g_cfg.flowDiv != 2 && g_cfg.flowDiv != 4 && g_cfg.flowDiv != 8) g_cfg.flowDiv = 4;
    if (g_cfg.step != 1 && g_cfg.step != 2 && g_cfg.step != 4 && g_cfg.step != 8) g_cfg.step = 4;
    if (g_cfg.lag < 1) g_cfg.lag = 1;
    if (g_cfg.lag > 4) g_cfg.lag = 4;
    if (g_cfg.engine != 1) g_cfg.engine = 0;
}

void before_swap(EGLDisplay dpy, EGLSurface surf, SwapFn plain) {
    if (!plain || g.failed) return;
    EGLContext ctx = eglGetCurrentContext();
    if (ctx == EGL_NO_CONTEXT || eglGetCurrentSurface(EGL_DRAW) != surf) return;
    EGLint w = 0, h = 0;
    eglQuerySurface(dpy, surf, EGL_WIDTH, &w);
    eglQuerySurface(dpy, surf, EGL_HEIGHT, &h);
    if (w < 640 || h < 360) return;  // abaikan surface kecil / offscreen

    const uint64_t t0 = now_ns();
    if (g.ctx != EGL_NO_CONTEXT && (g.ctx != ctx || g.surf != surf)) {
        if (t0 - g.lastNs < 2000000000ull) return;  // context/surface lain, instans utama masih hidup
        g = Inst();                                  // instans lama sudah mati: lepas (objek GL lama bocor)
    }
    if (g.ctx == EGL_NO_CONTEXT) {
        const char* ver = (const char*)glGetString(GL_VERSION);
        if (!ver || !strstr(ver, "OpenGL ES 3")) {
            LOGE("bukan GLES3 (%s): dinonaktifkan", ver ? ver : "?");
            g.failed = true;
            g.ctx = ctx;
            return;
        }
        g.ctx = ctx;
        g.surf = surf;
    }
    if (g.w != w || g.h != h) {
        EGLContext c = g.ctx;
        EGLSurface sf = g.surf;
        destroy(g, true);
        g.ctx = c;
        g.surf = sf;
        g.w = w;
        g.h = h;
    }
    g.lastNs = t0;

    Saved st;
    save_state(st);
    if (!g.ok) {
        if (!init_resources(g)) {
            LOGE("init gagal, dinonaktifkan");
            destroy(g, true);
            g.failed = true;
            g.ctx = ctx;
            restore_state(st);
            return;
        }
        g.ok = true;
    }
    begin_work();

    const bool cpuMode = g_cfg.engine == 1;
    const int lag = cpuMode ? g_cfg.lag : 0;
    const uint64_t n = g.n++;
    const int K = g.K;
    const int k = (int)(n % (uint64_t)K);

    capture(g, k);
    run_luma(g, k);
    if (cpuMode) {
        issue_readback(g, n);
        poll_readbacks(g);
    }

    // Frame yang ditampilkan sekarang = frame ke-(n - lag). Mode GPU lag 0, mode CPU lag 2-3
    // supaya flow punya waktu dihitung tanpa menahan pipeline GPU.
    const uint64_t head = n >= (uint64_t)lag ? n - (uint64_t)lag : 0;
    const int kh = (int)(head % (uint64_t)K);
    const int kp = head >= 1 ? (int)((head - 1) % (uint64_t)K) : 0;
    bool mid = false;
    if (head >= 1) {
        if (!cpuMode) {
            run_flow(g, kp, kh);
            mid = true;
        } else {
            mid = fetch_flow(g, head);
        }
    }
    if (mid) {
        draw_warp(g, kp, kh);
        plain(dpy, surf);  // tampilkan frame sisipan
        g.sMid++;
    }
    if (lag > 0 || mid) draw_blit(g, kh);  // frame yang akan di-swap oleh game sendiri

    while (glGetError() != GL_NO_ERROR) {}
    restore_state(st);

    g.sFrames++;
    g.sMs += (double)(now_ns() - t0) / 1e6;
    if (g.sFrames % 300 == 0) {
        LOGI("%s: %llu frame, sisipan %.0f%%, rata-rata waktu hook %.2f ms", cpuMode ? "CPU" : "GPU",
             (unsigned long long)g.sFrames, 100.0 * (double)g.sMid / (double)g.sFrames,
             g.sMs / (double)g.sFrames);
        g.sFrames = g.sMid = 0;
        g.sMs = 0;
    }
}

}  // namespace hfg
