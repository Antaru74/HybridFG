#include "cpuflow.h"

#include <android/log.h>
#include <arm_neon.h>
#include <sched.h>
#include <sys/prctl.h>

#include <cstdlib>
#include <cstring>
#include <time.h>

namespace hfg {
namespace {

constexpr int PAD = 24;  // > 2 + 15 (jangkauan maksimum) supaya SAD tidak perlu clamp

inline int sad8x8(const uint8_t* a, const uint8_t* b, int stride) {
    uint16x8_t acc = vdupq_n_u16(0);
    for (int r = 0; r < 8; ++r)
        acc = vabal_u8(acc, vld1_u8(a + r * stride), vld1_u8(b + r * stride));
    return (int)vaddvq_u16(acc);
}

}  // namespace

CpuFlow::CpuFlow(int lw, int lh, int step, unsigned cpuMask)
    : lw_(lw), lh_(lh), step_(step), mask_(cpuMask) {
    th_ = std::thread(&CpuFlow::run, this);
}

CpuFlow::~CpuFlow() {
    {
        std::lock_guard<std::mutex> l(mu_);
        stop_ = true;
    }
    cv_.notify_all();
    if (th_.joinable()) th_.join();
}

void CpuFlow::submit(uint64_t id, const uint8_t* luma) {
    Job j;
    j.id = id;
    j.luma.assign(luma, luma + (size_t)lw_ * lh_);
    std::lock_guard<std::mutex> l(mu_);
    if (jobs_.size() >= 4) jobs_.pop_front();
    jobs_.push_back(std::move(j));
    cv_.notify_one();
}

bool CpuFlow::take(uint64_t id, std::vector<uint8_t>& out) {
    std::lock_guard<std::mutex> l(mu_);
    while (!res_.empty() && res_.front().id < id) res_.pop_front();
    if (!res_.empty() && res_.front().id == id) {
        out = std::move(res_.front().data);
        res_.pop_front();
        return true;
    }
    return false;
}

std::vector<uint8_t> CpuFlow::pad(const std::vector<uint8_t>& raw) const {
    const int S = lw_ + 2 * PAD;
    const int H = lh_ + 2 * PAD;
    std::vector<uint8_t> p((size_t)S * H);
    for (int y = 0; y < lh_; ++y) {
        uint8_t* row = &p[(size_t)(y + PAD) * S];
        const uint8_t* src = &raw[(size_t)y * lw_];
        memcpy(row + PAD, src, lw_);
        memset(row, src[0], PAD);
        memset(row + PAD + lw_, src[lw_ - 1], PAD);
    }
    for (int y = 0; y < PAD; ++y) {
        memcpy(&p[(size_t)y * S], &p[(size_t)PAD * S], S);
        memcpy(&p[(size_t)(PAD + lh_ + y) * S], &p[(size_t)(PAD + lh_ - 1) * S], S);
    }
    return p;
}

void CpuFlow::compute(const uint8_t* prev, const uint8_t* cur, std::vector<uint8_t>& out) const {
    const int S = lw_ + 2 * PAD;
    const int fw = lw_ / 4, fh = lh_ / 4;
    out.resize((size_t)fw * fh * 2);
    for (int by = 0; by < fh; ++by) {
        for (int bx = 0; bx < fw; ++bx) {
            const size_t off = (size_t)(PAD + by * 4 - 2) * S + PAD + bx * 4 - 2;
            const uint8_t* c = cur + off;
            const uint8_t* p = prev + off;
            int bdx = 0, bdy = 0;
            int bestC = sad8x8(c, p, S);
            for (int s = step_; s >= 1; s >>= 1) {
                const int cx = bdx, cy = bdy;
                for (int j = -1; j <= 1; ++j) {
                    for (int i = -1; i <= 1; ++i) {
                        if (i == 0 && j == 0) continue;
                        const int dx = cx + i * s, dy = cy + j * s;
                        const int cost = sad8x8(c, p + dy * S + dx, S) + kBias * (abs(dx) + abs(dy));
                        if (cost < bestC) { bestC = cost; bdx = dx; bdy = dy; }
                    }
                }
            }
            uint8_t* o = &out[((size_t)by * fw + bx) * 2];
            o[0] = (uint8_t)(bdx + 128);
            o[1] = (uint8_t)(bdy + 128);
        }
    }
}

void CpuFlow::run() {
    prctl(PR_SET_NAME, "hfg-flow", 0, 0, 0);
    if (mask_) {
        cpu_set_t set;
        CPU_ZERO(&set);
        for (int i = 0; i < 32; ++i)
            if (mask_ & (1u << i)) CPU_SET(i, &set);
        sched_setaffinity(0, sizeof(set), &set);  // 0 = thread pemanggil
    }
    std::vector<uint8_t> last;
    uint64_t lastId = ~0ull;
    double totalMs = 0;
    int count = 0;
    for (;;) {
        Job j;
        {
            std::unique_lock<std::mutex> l(mu_);
            cv_.wait(l, [&] { return stop_ || !jobs_.empty(); });
            if (stop_) return;
            j = std::move(jobs_.front());
            jobs_.pop_front();
        }
        std::vector<uint8_t> cur = pad(j.luma);
        if (lastId != ~0ull && j.id == lastId + 1) {
            Res r;
            r.id = j.id;
            timespec a, b;
            clock_gettime(CLOCK_MONOTONIC, &a);
            compute(last.data(), cur.data(), r.data);
            clock_gettime(CLOCK_MONOTONIC, &b);
            totalMs += (b.tv_sec - a.tv_sec) * 1e3 + (b.tv_nsec - a.tv_nsec) / 1e6;
            if (++count == 300) {
                __android_log_print(ANDROID_LOG_INFO, "HybridFG", "flow CPU: rata-rata %.2f ms/frame", totalMs / count);
                totalMs = 0;
                count = 0;
            }
            std::lock_guard<std::mutex> l(mu_);
            res_.push_back(std::move(r));
            while (res_.size() > 8) res_.pop_front();
        }
        last = std::move(cur);
        lastId = j.id;
    }
}

}  // namespace hfg
