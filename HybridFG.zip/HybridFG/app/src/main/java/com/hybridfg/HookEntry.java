package com.hybridfg;

import android.os.Process;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.IXposedHookZygoteInit;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XSharedPreferences;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * Titik masuk LSPosed. Tugasnya hanya jadi "loader": memuat library native ke proses game,
 * lalu native meng-hook eglSwapBuffers (Xposed API tidak bisa menjangkau fungsi native).
 */
public class HookEntry implements IXposedHookZygoteInit, IXposedHookLoadPackage {
    private static String sModulePath;
    private static boolean sInit;

    @Override
    public void initZygote(StartupParam param) {
        sModulePath = param.modulePath;
    }

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) {
        if (Config.MODULE_PKG.equals(lp.packageName)) {
            // penanda status "modul aktif" di UI
            XposedHelpers.findAndHookMethod(MainActivity.class.getName(), lp.classLoader,
                    "isModuleActive", new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            param.setResult(true);
                        }
                    });
            return;
        }
        if (!lp.packageName.equals(lp.processName)) return; // hanya proses utama

        XSharedPreferences sp = new XSharedPreferences(Config.MODULE_PKG, Config.PREFS);
        if (!sp.getBoolean("enabled", true)) return;
        if (!Config.contains(sp.getString("packages", ""), lp.packageName)) return;
        if (!Process.is64Bit() || sInit) return;
        sInit = true;

        try {
            loadNative();
            Native.init(
                    sp.getInt("engine", 0),
                    sp.getInt("flow_div", 4),
                    sp.getInt("step", 4),
                    sp.getInt("lag", 2),
                    sp.getInt("cpu_mask", 0xC0));
            XposedBridge.log("HybridFG: aktif di " + lp.packageName);
        } catch (Throwable t) {
            XposedBridge.log("HybridFG: gagal memuat native: " + t);
        }
    }

    private static void loadNative() {
        try {
            System.loadLibrary("shadowhook");
            System.loadLibrary("hybridfg");
            return;
        } catch (Throwable ignored) {
            // lanjut ke jalur eksplisit lewat path APK modul
        }
        String base = sModulePath + "!/lib/arm64-v8a/";
        System.load(base + "libshadowhook.so");
        System.load(base + "libhybridfg.so");
    }
}
