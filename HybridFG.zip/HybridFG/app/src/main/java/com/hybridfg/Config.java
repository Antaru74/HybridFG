package com.hybridfg;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;

final class Config {
    static final String MODULE_PKG = "com.hybridfg";
    static final String PREFS = "config";
    static final String DEFAULT_PACKAGES = "com.kurogame.gplay.punishing.grayraven.en";

    private Config() {}

    @SuppressLint({"WorldReadableFiles"})
    @SuppressWarnings("deprecation")
    static SharedPreferences prefs(Context c) {
        try {
            // LSPosed mengizinkan ini untuk modul aktif, supaya XSharedPreferences di proses game bisa membaca
            return c.getSharedPreferences(PREFS, Context.MODE_WORLD_READABLE);
        } catch (SecurityException e) {
            return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        }
    }

    static boolean contains(String list, String pkg) {
        if (list == null) return false;
        for (String s : list.split("[,;\\s]+")) {
            if (s.equals(pkg)) return true;
        }
        return false;
    }
}
