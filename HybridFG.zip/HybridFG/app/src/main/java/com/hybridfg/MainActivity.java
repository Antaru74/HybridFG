package com.hybridfg;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends Activity {
    /** Di-hook oleh HookEntry supaya mengembalikan true saat modul aktif. */
    public static boolean isModuleActive() {
        return false;
    }

    private static final String[] DIV = {"2", "4", "8"};
    private static final String[] STEP = {"2", "4", "8"};
    private static final String[] LAG = {"2", "3"};

    private SharedPreferences sp;
    private Switch swOn;
    private RadioButton rbGpu, rbCpu;
    private Spinner spDiv, spStep, spLag;
    private EditText etMask, etPkgs;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = Config.prefs(this);

        ScrollView sv = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int p = dp(16);
        root.setPadding(p, p, p, p);
        sv.addView(root);
        setContentView(sv);

        root.addView(label(isModuleActive()
                ? "Status: modul aktif di LSPosed"
                : "Status: modul belum aktif (aktifkan di LSPosed, centang game, restart game)"));

        swOn = new Switch(this);
        swOn.setText("Aktifkan frame generation");
        swOn.setChecked(sp.getBoolean("enabled", true));
        root.addView(swOn);

        root.addView(label("Engine estimasi gerakan (flow)"));
        RadioGroup rg = new RadioGroup(this);
        rg.setOrientation(RadioGroup.HORIZONTAL);
        rbGpu = new RadioButton(this);
        rbGpu.setText("GPU");
        rbGpu.setId(View.generateViewId());
        rbCpu = new RadioButton(this);
        rbCpu.setText("CPU");
        rbCpu.setId(View.generateViewId());
        rg.addView(rbGpu);
        rg.addView(rbCpu);
        (sp.getInt("engine", 0) == 1 ? rbCpu : rbGpu).setChecked(true);
        root.addView(rg);

        spDiv = spinner(root, "Skala flow (2 = detail tinggi, 8 = ringan)", DIV, String.valueOf(sp.getInt("flow_div", 4)));
        spStep = spinner(root, "Jangkauan gerakan (2 = ±3, 4 = ±7, 8 = ±15 piksel flow)", STEP, String.valueOf(sp.getInt("step", 4)));
        spLag = spinner(root, "Lag frame mode CPU (lebih besar = lebih tahan telat, latensi naik)", LAG, String.valueOf(sp.getInt("lag", 2)));

        root.addView(label("Core CPU untuk thread flow (hex bitmask, C0 = cpu6+cpu7)"));
        etMask = new EditText(this);
        etMask.setInputType(InputType.TYPE_CLASS_TEXT);
        etMask.setText(Integer.toHexString(sp.getInt("cpu_mask", 0xC0)).toUpperCase());
        root.addView(etMask);

        root.addView(label("Package game (satu per baris)"));
        etPkgs = new EditText(this);
        etPkgs.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        etPkgs.setMinLines(3);
        etPkgs.setText(sp.getString("packages", Config.DEFAULT_PACKAGES));
        root.addView(etPkgs);

        Button pick = new Button(this);
        pick.setText("Pilih dari aplikasi terpasang");
        pick.setOnClickListener(v -> pickApps());
        root.addView(pick);

        Button save = new Button(this);
        save.setText("Simpan (restart game setelahnya)");
        save.setOnClickListener(v -> save());
        root.addView(save);
    }

    private void save() {
        int mask;
        try {
            mask = Integer.parseInt(etMask.getText().toString().trim(), 16);
        } catch (Exception e) {
            mask = 0xC0;
        }
        sp.edit()
                .putBoolean("enabled", swOn.isChecked())
                .putInt("engine", rbCpu.isChecked() ? 1 : 0)
                .putInt("flow_div", Integer.parseInt((String) spDiv.getSelectedItem()))
                .putInt("step", Integer.parseInt((String) spStep.getSelectedItem()))
                .putInt("lag", Integer.parseInt((String) spLag.getSelectedItem()))
                .putInt("cpu_mask", mask)
                .putString("packages", etPkgs.getText().toString())
                .apply();
        Toast.makeText(this, "Tersimpan. Restart game.", Toast.LENGTH_SHORT).show();
    }

    private void pickApps() {
        final PackageManager pm = getPackageManager();
        List<ApplicationInfo> apps = pm.getInstalledApplications(0);
        Collections.sort(apps, (a, c) -> pm.getApplicationLabel(a).toString()
                .compareToIgnoreCase(pm.getApplicationLabel(c).toString()));
        final List<String> pk = new ArrayList<>();
        final List<String> lb = new ArrayList<>();
        for (ApplicationInfo ai : apps) {
            if (pm.getLaunchIntentForPackage(ai.packageName) != null
                    && !ai.packageName.equals(getPackageName())) {
                pk.add(ai.packageName);
                lb.add(pm.getApplicationLabel(ai) + "\n" + ai.packageName);
            }
        }
        final Set<String> cur = new LinkedHashSet<>(Arrays.asList(etPkgs.getText().toString().split("[,;\\s]+")));
        final boolean[] chk = new boolean[pk.size()];
        for (int i = 0; i < chk.length; i++) chk[i] = cur.contains(pk.get(i));

        new AlertDialog.Builder(this)
                .setTitle("Pilih game")
                .setMultiChoiceItems(lb.toArray(new String[0]), chk, (d, which, checked) -> chk[which] = checked)
                .setPositiveButton("OK", (d, w) -> {
                    Set<String> out = new LinkedHashSet<>();
                    for (String s : cur) if (!s.isEmpty() && !pk.contains(s)) out.add(s);
                    for (int i = 0; i < chk.length; i++) if (chk[i]) out.add(pk.get(i));
                    etPkgs.setText(TextUtils.join("\n", out));
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    private Spinner spinner(LinearLayout root, String label, String[] items, String cur) {
        root.addView(label(label));
        Spinner s = new Spinner(this);
        s.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items));
        for (int i = 0; i < items.length; i++) if (items[i].equals(cur)) s.setSelection(i);
        root.addView(s);
        return s;
    }

    private TextView label(String t) {
        TextView tv = new TextView(this);
        tv.setText(t);
        tv.setPadding(0, dp(12), 0, dp(4));
        return tv;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }
}
