package com.hybridfg;

/** Jembatan JNI ke libhybridfg.so (dimuat oleh HookEntry di proses game). */
final class Native {
    private Native() {}

    static native void init(int engine, int flowDiv, int step, int lag, int cpuMask);
}
